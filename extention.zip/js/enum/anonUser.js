function makeAnonUser(id, gender, age, country){
    return {
        id: id,
        gender: gender,
        age: age,
        country: country,
        //? isFriend
    };
}