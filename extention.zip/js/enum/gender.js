var GENDER = {
    MALE: 1,
    FEMALE: 2,
    UNKNOWN: 3
};