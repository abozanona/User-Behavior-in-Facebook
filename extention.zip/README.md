# Welcome to FPWA
## Facebook Privacy Watcher & Analyzer

### What is FPWA?
FPWA (Facebook Privacy Watcher and Analyzer) is a browser extension (i.e. plug-in) for Google Chrome.
It collects data about the privacy settings as well as about behavior of Facebook users.
It also helps users to customize their privacy settings on Facebook.

## About us
### Which universities working on this study?
In this study, two universities the researchers belongs to:
* Palestine Polytechnic University
* Technische Universität Darmstadt

### Who we are?
We are a research group in computer field, our group:

*Hani Salah - hani@ppu.edu

*PhD Thomas Paul - thomas.paul@cs.tu-darmstadt.de

*Eng. Abdulhamead Abuzanunah - abozanona@gmail.com

*Eng. Meqdad darweesh - meqdad.darweesh@gmail.com

*Eng. Hamzah Bahar - hamzah.bahar@outlook.com
